import { test, expect} from '@playwright/test';
import testData from '../dataTest/testData.json';

test('Login with parameterized test', async ({ page }) => {

    for(const data of testData)
    {
        await page.goto("https://demo.nopcommerce.com/");
        await page.locator('.ico-login').click();
        await page.locator("//div[@class='form-fields']//input[@class='email']").fill(data.username);
        await page.locator("//div[@class='form-fields']//input[@class='password']").fill(data.password);
        await page.locator("//button[@class='button-1 login-button']").click();
        await page.locator('.ico-logout').click();
    }
    
});
