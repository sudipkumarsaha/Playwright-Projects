import { test, expect } from "@playwright/test";
import { userRegistration } from '../PageObject/userRegistration';
import { loginUser } from '../PageObject/loginUser';
import { wishlist } from '../PageObject/wishlist';
import { orderCheckout } from "../PageObject/orderCheckout";
import { resolve } from 'node:dns';
import { POManager } from "../PageObject/POManager";
import testData from '../dataTest/testData.json';



test('Register user', async({page})=>
{
    const firstname = "Sudip";
    const lastname = "Saha";
    const email = "test5@test.com";
    const companyname = "Test ABC";
    const password = "Test1234";
    const confirmpassword = "Test1234";
    const register_a_user = new userRegistration(page);
    await register_a_user.launchURL();
    await register_a_user.newRegistration(firstname,lastname,email,companyname,password,confirmpassword);
    const register_confirmation = page.locator("//div[@class='page registration-result-page']//div[@class='result']");
    await expect(register_confirmation).toHaveText("Your registration completed");
    await page.locator("//div[@class='page registration-result-page']//a[@class='button-1 register-continue-button']").click();
});


test('login user', async({page})=>
{

    //await page.goto("https://demo.nopcommerce.com/");
    //const poManager = new POManager(page);
    //const performLogin = await poManager.getloginUser();
    //await performLogin.newLogin(data.username, data.password);
    const login = new loginUser(page);
    await login.launchURL();
    await login.newLogin(loginemail, loginpass);
});

test('Place an order',async({page})=>
{
    await page.goto("https://demo.nopcommerce.com/");
    const loginemail = "sudip7@gmail.com";
    const loginpass = "Sudip@1";
    const login = new loginUser(page);
    await login.launchURL();
    await login.newLogin(loginemail,loginpass);
    await login.navigate(); //navigate to propaganda hat after login.
    const sizedropdown = page.locator("//div[@class='attributes']//select[@id='product_attribute_13']");
    await sizedropdown.selectOption("Medium");
    await page.waitForTimeout(8000);
    const AddtoWishList = new wishlist(page);
    await AddtoWishList.AddUpdatetoWishlist();
    const closeWishlistpopup = page.locator("//div[@class='bar-notification']//span[@class='close']");
    const test = closeWishlistpopup.isVisible();
        if(test==true)
        {
            await this.closeWishlistpopup.click();
        }
    await AddtoWishList.WishlistPage();
    const newOrderCheckout = new orderCheckout(page);
    await newOrderCheckout.OrderCheckout();
    //Update Billing Information 
    const editBilling = page.locator("//div[@class='opc-select-address-container']//button[@id='edit-billing-address-button']").isVisible();
    if (editBilling==false)
    {
        const selectcountry = page.locator("//select[@id='BillingNewAddress_CountryId']");
        const selectstate = page.locator("//select[@id='BillingNewAddress_StateProvinceId']");
        const cityname = page.locator("//input[@id='BillingNewAddress_City']");
        const address = page.locator("//input[@id='BillingNewAddress_Address1']");
        const zipcode = page.locator("//input[@id='BillingNewAddress_ZipPostalCode']");
        const phonenumber = page.locator("//input[@id='BillingNewAddress_PhoneNumber']");
        await selectcountry.selectOption("India");
        await selectstate.selectOption("Kerala");
        await cityname.fill("Cochin");
        await address.fill("1, cocin road");
        await zipcode.fill("12345");
        await phonenumber.fill("1234567890");
    }
    const contBilling = page.locator("//div[@id='billing-buttons-container']//button[@class='button-1 new-address-next-step-button']");
    await contBilling.click();
    //const newCheckout = new orderCheckout(page);
    await newOrderCheckout.contCheckout();
    await newOrderCheckout.OrdConfirmation();
    const orderInfo = page.locator("//div[@class='order-overview']//div[@class='order-number']/strong");
    const orderNum = await orderInfo.textContent();
    console.log(orderNum);
    const ordNum = orderNum.toString().split("#");
    console.log(ordNum[1]);
    console.log("Thank you for placing an Order, the order number is:" +ordNum[1]);
});

test('Split', async({page})=> 
{
    const orderNumber = "Order #7";
    const ordNum = orderNumber.split("#");
    console.log(ordNum[1]);

});