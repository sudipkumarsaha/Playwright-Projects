import {test, expect} from '@playwright/test';
import path from 'path';
import fs from 'fs';

test.only('Download File', async({page})=>{

    await page.goto("https://www.selenium.dev/downloads/");
    const [download] = await Promise.all([
        page.waitForEvent('download'),
        page.locator("//a[text()='32 bit Windows IE']").click() //listens for the download event
    ]);
    const projectDirectory = path.join(__dirname,'downloads');
    await page.waitForTimeout(3000);
    if(!fs.existsSync(projectDirectory)){
        fs.mkdirSync(projectDirectory);
    }
    const filepath = path.join(projectDirectory, 'selenium.jar');
    await download.saveAs(filepath);
    console.log(filepath);

});